<!-- edit_financial_advisor.blade.php -->


<?php $__env->startSection('content'); ?>
<div class="page-body">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Edit Financial Advisor</h4>
                        <p class="f-m-light mt-1">Edit Financial Advisor Contact Details by filling the form below.</p>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="<?php echo e(route('financial_advisors.update', $financialAdvisor->id)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="row">
                            <!-- Full Name -->
                            <div class="col-lg-4 col-md-4 col-sm-12 mb-4">
                            <div class="form-group">
                                <label for="full_name">Full Name:</label>
                                <input type="text" class="form-control" id="full_name" name="full_name" value="<?php echo e($financialAdvisor->name); ?>">
                            </div>
                            </div>
                            <!-- Email -->
                            <div class="col-lg-4 col-md-4 col-sm-12 mb-4">
                            <div class="form-group">
                                <label for="email">Email:</label>
                                <input type="email" class="form-control" id="email" name="email" value="<?php echo e($financialAdvisor->email); ?>">
                            </div>
                            </div>
                            <!-- Contact Number -->
                            <div class="col-lg-4 col-md-4 col-sm-12 mb-4">
                            <div class="form-group">
                                <label for="contact_number">Contact Number:</label>
                                <input type="text" class="form-control" id="contact_number" name="contact_number" value="<?php echo e($financialAdvisor->contact_number); ?>">
                            </div>
                            </div>
                            <!-- Address -->
                            <div class="col-lg-4 col-md-4 col-sm-12 mb-4">
                            <div class="form-group">
                                <label for="street">Street:</label>
                                <input type="text" class="form-control" id="street" name="street" value="<?php echo e($financialAdvisor->street); ?>">
                            </div>
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-12 mb-4">
                            <div class="form-group">
                                <label for="city">City:</label>
                                <input type="text" class="form-control" id="city" name="city" value="<?php echo e($financialAdvisor->city); ?>">
                            </div>
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-12 mb-4">
                            <div class="form-group">
                                <label for="state">State:</label>
                                <input type="text" class="form-control" id="state" name="state" value="<?php echo e($financialAdvisor->state); ?>">
                            </div>
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-12 mb-4">
                            <div class="form-group">
                                <label for="zip_code">Zip Code:</label>
                                <input type="text" class="form-control" id="zip_code" name="zip_code" value="<?php echo e($financialAdvisor->zip_code); ?>">
                            </div>
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-12 mb-4">
                            <div class="form-group">
                                <label for="country">Country:</label>
                                <input type="text" class="form-control" id="country" name="country" value="<?php echo e($financialAdvisor->country); ?>">
                            </div>
                            </div>
                            </div>
                            <!-- Update Button -->
                            <button type="submit" class="btn btn-primary">Update</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\finance_portal\resources\views/financial_advisors/edit_financial_advisor.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>
<div class="page-body">
                <!-- Container-fluid starts-->
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card">
                            <div class="card-header">
                        <h4>Notifications</h4>
                        <p class="f-m-light mt-1">List of All Notifications.</p>
                    </div>
                                <div class="card-body">
                                    <div class="form theme-form">
                                    <div class="row">
              <!-- Zero Configuration  Starts-->
              <div class="col-sm-12">

                    <div class="table-responsive theme-scrollbar">
                      <div id="basic-1_wrapper" class="dataTables_wrapper no-footer">
                        <div class="dataTables_length" id="basic-1_length"></div><table class="display dataTable no-footer" id="basic-1" role="grid" aria-describedby="basic-1_info">
                      <thead>
                                                        <tr role="row">
                                                            <th>Notification Title</th>
                                                            <th>Notification Description</th>
                                                            <th>Date</th>
                                                            <th>Status</th>
                                                            <th>Actions</th>
                                                        </tr>
                                                    </thead>
                        <tbody>
                        <tr role="row" class="odd">
                            <td class="sorting_1">Christmas Holiday</td>
                            <td>Enjoy Christmas Holidays From 25th Dec to 28th Dec.</td>
                            <td>10 Dec,2024</td>
                            <td>Read</td>
                            <td> 
                              <button class="btn btn-primary">Mark as Un-read</button>
                            </td>
                          </tr></tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
              <!-- Zero Configuration  Ends-->
              <!-- Complex headers (rowspan and colspan) Starts-->
                                
                </div>
              </div>
              <!-- Scroll - vertical dynamic Ends-->
            </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Container-fluid Ends-->
            </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\finance_portal\resources\views/notifications/view_notifications.blade.php ENDPATH**/ ?>
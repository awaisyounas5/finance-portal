<?php $__env->startSection('content'); ?>
<div class="page-body">
    <!-- Container-fluid starts-->
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-body">
                        <div class="form theme-form">
                            <!-- Display Success Message -->
                            <?php if(session('success')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('success')); ?>

                                </div>
                            <?php endif; ?>
                            <!-- Display Error Message -->
                            <?php if(session('error')): ?>
                                <div class="alert alert-danger">
                                    <?php echo e(session('error')); ?>

                                </div>
                            <?php endif; ?>
                            <h4>Edit Macroeconomic Document</h4>
                            <!-- Display Previous Documents -->
                            <div class="mb-3">
                                <label>Previous Documents</label><br>
                                <?php $__currentLoopData = json_decode($document->file_path); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $filePath): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="d-flex align-items-center mb-2">
                                        <a href="<?php echo e(asset('documents/' . $filePath)); ?>" target="_blank"><?php echo e(basename($filePath)); ?></a>
                                        <form action="<?php echo e(route('macroeconomic-documents.delete', ['id' => $document->id, 'filename' => basename($filePath)])); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-danger ms-2">Delete</button>
                                        </form>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            
                            <!-- Add New Document -->
                            <form action="<?php echo e(route('macroeconomic-documents.update', $document->id)); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="row">
                                    <div class="col">
                                        <div class="mb-3">
                                            <label for="name">Document Name</label>
                                            <input type="text" class="form-control" id="name" name="name" value="<?php echo e($document->name); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col">
                                        <div class="mb-3">
                                            <label for="description">Document Description</label>
                                            <textarea class="form-control" id="description" name="description"><?php echo e($document->description); ?></textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col">
                                        <div class="mb-3">
                                            <label for="new_document">New Document</label>
                                            <input type="file" class="form-control" id="new_document" name="new_document[]" multiple>
                                            <small class="text-muted">You can select multiple files by pressing Ctrl or Command key</small>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col">
                                        <div class="text-end">
                                            <button type="submit" class="btn btn-primary">Update Document</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Container-fluid Ends-->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\finance_portal\resources\views/macroeconomic_outlook/edit.blade.php ENDPATH**/ ?>
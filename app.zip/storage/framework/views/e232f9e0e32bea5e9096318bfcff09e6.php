<?php $__env->startSection('content'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<div class="page-body">
    <!-- Container-fluid starts-->
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Documents List By Financial Advisors</h4>
                        <p class="f-m-light mt-1">List of All The Documents Uploaded By Financial Advisors.</p>
                    </div>
                    <div class="card-body">
                        <div class="form theme-form">
                            <?php if(session('error')): ?>
                            <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                            <?php endif; ?>
                            <?php if(session('success')): ?>
                            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                            <?php endif; ?>
                            <div class="row">
                                <!-- Zero Configuration Starts-->
                                <div class="col-sm-12">
                                    <div class="table-responsive theme-scrollbar">
                                        <table class="display dataTable no-footer" id="basic-1" role="grid" aria-describedby="basic-1_info">
                                            <thead>
                                                <tr role="row">
                                                    <th>Financial Advisor Name</th>
                                                    <th>Email</th>
                                                    <th>Document Name</th>
                                                    <th>Description</th>
                                                    <th>Attachment</th>
                                                    <th>Upload Date</th>
                                                    <th>Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr role="row" class="odd">
                                                    <td><?php echo e($document->financial_advisor->name); ?></td>
                                                    <td><?php echo e($document->financial_advisor->email); ?></td>
                                                    <td><?php echo e($document->name); ?></td>
                                                    <td><?php echo e($document->description); ?></td>
                                                    <td><a href="<?php echo e(asset('documents/' . $document->file_path)); ?>">View Attachment</a></td>
                                                    <td><?php echo e($document->created_at->format('d-m-Y')); ?></td>
                                                    <td style="display:inline-flex;gap:5px;">
                                                        <button type="button" class="btn btn-primary btn-sm edit-btn" data-id="<?php echo e($document->id); ?>" data-toggle="tooltip" data-placement="top" title="Edit">
                                                            <i class="fa fa-edit"></i>
                                                        </button>
                                                        <form action="<?php echo e(route('documents.destroy', $document->id)); ?>" method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="button" class="btn btn-danger btn-sm" data-toggle="tooltip" data-placement="top" title="Delete" onclick="showConfirmation(this)">
                                                                <i class="fa fa-trash"></i>
                                                            </button>
                                                        </form>
                                                    </td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <!-- Zero Configuration Ends-->
                            </div>
                        </div>
                        <!-- Scroll - vertical dynamic Ends-->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</div>
<!-- Container-fluid Ends-->
</div>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        var editButtons = document.querySelectorAll('.edit-btn');
        editButtons.forEach(function(button) {
            button.addEventListener('click', function() {
                var documentId = button.getAttribute('data-id');
                window.location.href = '/documents/' + documentId + '/edit';
            });
        });
    });


    function showConfirmation(button) {
        var form = button.closest('form'); // Find the closest form element
        var formId = form.id; // Get the ID of the form

        if (typeof Swal === 'undefined') {
            // Fallback to browser confirm if Sweetalert is not loaded
            if (confirm('Are you sure you want to delete this document?')) {
                form.submit();
            }
            return;
        }

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
            if (result.isConfirmed) {
                // Submit the form if user confirms
                form.submit();
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\finance_portal\resources\views/documents/view_documents_all.blade.php ENDPATH**/ ?>
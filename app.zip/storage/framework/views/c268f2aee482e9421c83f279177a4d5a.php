<?php $__env->startSection('content'); ?>
<div class="page-body">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Edit Qna</h4>
                    </div>
                    <div class="card-body">
                        <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>

                        <?php if(session('success')): ?>
                        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                        <?php endif; ?>

                        <?php if(session('error')): ?>
                        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                        <?php endif; ?>

                        <form action="<?php echo e(route('sent_questionnaires.update', $qna->id)); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="mb-3">
                                <label for="question_subject" class="form-label">Question Subject</label>
                                <input type="text" class="form-control" id="question_subject" name="question_subject" value="<?php echo e(old('question_subject', $qna->question_subject)); ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="question_description" class="form-label">Question Description</label>
                                <textarea class="form-control" id="question_description" name="question_description" rows="3" required><?php echo e(old('question_description', $qna->question_description)); ?></textarea>
                            </div>
                            <div class="mb-3">
                                <label for="attachment" class="form-label">Attachment</label>
                                <input type="file" class="form-control" id="attachment" name="attachment">
                            </div>

                            <?php if($qna->attachment): ?>
                            <div class="mb-3">
                                <label>Previous Document</label><br>
                                <a href="<?php echo e(asset('documents/' . $qna->attachment)); ?>" target="_blank">View Previous Document</a><br>
                            </div>
                            <?php endif; ?>

                            <button type="submit" class="btn btn-primary">Update Qna</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\finance_portal\resources\views/questionares/edit.blade.php ENDPATH**/ ?>
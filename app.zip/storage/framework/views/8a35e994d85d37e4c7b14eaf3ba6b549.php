<?php $__env->startSection('content'); ?>
<div class="page-body">
    <!-- Container-fluid starts-->
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-body">
                        <div class="form theme-form">
                            <div class="row">
                                <!-- Zero Configuration  Starts-->
                                <div class="col-sm-12">
                                    <div class="card">
                                        <div class="card-body">
                                            <div class="table-responsive theme-scrollbar">
                                                <table class="display dataTable no-footer" id="basic-1" role="grid" aria-describedby="basic-1_info">
                                                    <thead>
                                                        <tr role="row">
                                                            <th>Name</th>
                                                            <th>Email</th>
                                                            <th>Contact Number</th>
                                                            <th>Address</th>
                                                            <th>Actions</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $financialAdvisors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $advisor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($advisor->name); ?></td>
                                                            <td><?php echo e($advisor->email); ?></td>
                                                            <td><?php echo e($advisor->contact_number); ?></td>
                                                            <td><?php echo e($advisor->street); ?>, <?php echo e($advisor->city); ?>, <?php echo e($advisor->state); ?>, <?php echo e($advisor->zip_code); ?>, <?php echo e($advisor->country); ?></td>
                                                            <td>
                                                                <button type="button" class="btn btn-primary btn-sm edit-btn" data-id="<?php echo e($advisor->id); ?>" data-toggle="tooltip" data-placement="top" title="Edit">
                                                                    <i class="fa fa-edit"></i>
                                                                </button>

                                                                <form action="<?php echo e(route('financial_advisors.destroy', $advisor->id)); ?>" method="POST">
                                                                    <?php echo csrf_field(); ?>
                                                                    <?php echo method_field('DELETE'); ?>
                                                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this advisor?')" data-toggle="tooltip" data-placement="top" title="Delete">
                                                                        <i class="fa fa-trash"></i>
                                                                    </button>
                                                                </form>
                                                            </td>
                                                        </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Zero Configuration  Ends-->
                                    <!-- Complex headers (rowspan and colspan) Starts-->

                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Scroll - vertical dynamic Ends-->
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</div>
<!-- Container-fluid Ends-->
</div>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        var editButtons = document.querySelectorAll('.edit-btn');
        editButtons.forEach(function(button) {
            button.addEventListener('click', function() {
                var advisorId = button.getAttribute('data-id');
                window.location.href = '/financial_advisors/' + advisorId + '/edit';
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\finance_portal\resources\views/view_financial_advisors.blade.php ENDPATH**/ ?>